======================
API
======================

Jacobi-Davidson iterative method module
-----------------------

.. automodule:: pydavidson
    :members:
    :undoc-members:
    :show-inheritance:

Gram-Schmidt Orthogonalization module
---------------------

.. automodule:: gs
    :members:
    :undoc-members:
    :show-inheritance:
